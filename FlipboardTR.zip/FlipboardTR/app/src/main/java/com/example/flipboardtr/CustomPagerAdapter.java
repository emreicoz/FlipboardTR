package com.example.flipboardtr;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.viewpager.widget.PagerAdapter;

import java.util.List;

class CustomPagerAdapter extends PagerAdapter {

    private List<Haber>  haberList;
    private Context context;
    private LayoutInflater inflater;


    public CustomPagerAdapter (Context context, List<Haber> haberList){

        this.context=context;
        this.haberList=haberList;
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }

    @Override
    public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
        return false;
    }

    @NonNull
    @Override
    public Object instantiateItem(@NonNull ViewGroup container, int position) {
        View view = inflater.inflate(R.layout.haber_sayfasi,container,false);
        //ImageView haberimageView = view.findViewById(R.id.haber_resim);
        TextView haberbasliktv = view.findViewById(R.id.haber_baslik);
        TextView haberkaynagitarihtv = view.findViewById(R.id.haber_kaynagi_tarih);
        TextView habericeriktv = view.findViewById(R.id.haber_icerik);

        Haber gecici = haberList.get(position);
        //haberimageView.getResources(gecici.getUrlToImage());
        haberbasliktv.setText(gecici.getTitlee());
        haberkaynagitarihtv.setText(gecici.getAuthor()+gecici.getPublishedAt());
        habericeriktv.setText(gecici.getContent());

        container.addView(view);
        return view;
    }

    @Override
    public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
        container.removeView((LinearLayout)object);
    }
    @Override
    public int getCount() {
        return haberList.size();
    }

}
