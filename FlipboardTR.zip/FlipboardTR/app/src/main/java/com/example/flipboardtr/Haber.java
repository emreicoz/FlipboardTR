package com.example.flipboardtr;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.os.PersistableBundle;

import androidx.annotation.Nullable;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;


public class Haber extends Activity {

    private String author;
    private String title;
    private String description;
    private String url;
    private String urlToImage;
    private String publishedAt;
    private String content;


    public Haber(String author, String title, String description, String url, String urlToImage, String publishedAt, String content) {
        setAuthor(author);
        setTitle(title);
        setContent(content);
        setDescription(description);
        setUrl(url);
        setUrlToImage(urlToImage);
        setPublishedAt(publishedAt);
        setContent(content);


    }




    /*public static List<Haber> getHaberList(RequestQueue mQueue){

        haberList = new ArrayList<>();
        String url = "https://newsapi.org/v2/top-headlines?country=tr&apiKey=3f158235fff247fb8670a05240f3e3c9";
        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("articles");


                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject articles =  jsonArray.getJSONObject(i);

                                String author = articles.getString("author");
                                String title = articles.getString("title");
                                String description = articles.getString("description");
                                String url = articles.getString("url");
                                String urlToImage = articles.getString("urlToImage");
                                String publishedAt = articles.getString("publishedAt");
                                String content = articles.getString("content");

                                Haber haber = new Haber(author, title, description, url, urlToImage, publishedAt, content);
                                haberList.add(haber);
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);

        return haberList;//boş dönüyor
    }*/


    public String getAuthor() {
        return author;
    }

    public String getTitlee() {
        return title;
    }

    public String getDescription() {
        return description;
    }

    public String getUrl() {
        return url;
    }

    public String getUrlToImage() {
        return urlToImage;
    }

    public String getPublishedAt() {
        return publishedAt;
    }

    public String getContent() {
        return content;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public void setUrlToImage(String urlToImage) {
        this.urlToImage = urlToImage;
    }

    public void setPublishedAt(String publishedAt) {
        this.publishedAt = publishedAt;
    }

    public void setContent(String content) {
        this.content = content;
    }
}
