package com.example.flipboardtr;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Context;
import android.os.Bundle;
import android.view.Menu;
import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.android.volley.RequestQueue;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    public RequestQueue mQueue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mQueue = Volley.newRequestQueue(this);
        String url = "https://newsapi.org/v2/top-headlines?country=tr&apiKey=3f158235fff247fb8670a05240f3e3c9";
        jSonitem jsonislem = new jSonitem(url,mQueue);
        //List<String> jsonarraystring = jsonislem.getjSonString(url,mQueue); // null geliyor

        ViewPager viewPager = findViewById(R.id.viewPager);

        CustomPagerAdapter customPagerAdapter;
        customPagerAdapter = new CustomPagerAdapter(this, jsonislem.getHaberList());

        viewPager.setAdapter(customPagerAdapter);


        Toolbar toolbar = (Toolbar) findViewById(R.id.ust_menu_toolbar);
        toolbar.setTitle("Flipboard");
        setSupportActionBar(toolbar);
        toolbar.inflateMenu(R.menu.toolbar_ust_menu);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.toolbar_ust_menu,menu);
        return true;

    }
}
