package com.example.flipboardtr;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.gson.Gson;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

public class jSonitem {
    private String url;
    private List<Haber> haberList;



    public jSonitem(String url, RequestQueue mQueue) {
        this.url = url;

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {

                            JSONArray jsonArray = response.getJSONArray("articles");


                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject articles =  jsonArray.getJSONObject(i);

                                String author = articles.getString("author");
                                String title = articles.getString("title");
                                String description = articles.getString("description");
                                String url = articles.getString("url");
                                String urlToImage = articles.getString("urlToImage");
                                String publishedAt = articles.getString("publishedAt");
                                String content = articles.getString("content");

                                haberList.add(new Haber(author, title, description, url, urlToImage, publishedAt, content));
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });

        mQueue.add(request);

    }

    /*public List<String> getjSonList(RequestQueue mQueue) {

        JsonObjectRequest request = new JsonObjectRequest(Request.Method.GET, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        try {
                            JSONArray jsonArray = response.getJSONArray("articles");

                            for (int i = 0; i < jsonArray.length(); i++) {

                                JSONObject articles = jsonArray.getJSONObject(i);


                                jSonString.add(articles.toString());
                            }

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        });
        mQueue.add(request);
        return jSonString;
    }*/

    public List<Haber> getHaberList() {
        return haberList;
    }
}

